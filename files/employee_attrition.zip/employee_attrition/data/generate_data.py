"""
generate_data.py
-----------------
Generates a synthetic employee attrition dataset that mimics a typical
HR analytics database (similar in spirit to the well-known IBM HR
Analytics Attrition dataset). Swap this out for your own company's HR
export in a real deployment.

Output: data/employee_data.csv
"""

import numpy as np
import pandas as pd

np.random.seed(42)

N = 4000  # number of employees


def generate_dataset(n=N):
    age = np.random.randint(20, 60, n)
    monthly_income = np.random.normal(6000, 2500, n).clip(1500, 25000)
    years_at_company = np.random.randint(0, 25, n)
    years_since_promotion = np.random.randint(0, 12, n)
    years_with_manager = np.random.randint(0, 15, n)
    distance_from_home = np.random.randint(1, 40, n)
    job_level = np.random.randint(1, 6, n)
    num_companies_worked = np.random.randint(0, 8, n)
    training_times_last_year = np.random.randint(0, 6, n)
    overtime = np.random.choice(["Yes", "No"], n, p=[0.3, 0.7])
    job_satisfaction = np.random.randint(1, 5, n)      # 1=Low ... 4=Very High
    work_life_balance = np.random.randint(1, 5, n)     # 1=Bad ... 4=Best
    environment_satisfaction = np.random.randint(1, 5, n)
    performance_rating = np.random.randint(1, 5, n)
    percent_salary_hike = np.random.randint(5, 25, n)
    department = np.random.choice(
        ["Sales", "R&D", "HR", "Marketing", "Engineering", "Finance"], n
    )
    job_role = np.random.choice(
        ["Manager", "Executive", "Analyst", "Technician", "Representative", "Director"], n
    )
    marital_status = np.random.choice(["Single", "Married", "Divorced"], n, p=[0.35, 0.5, 0.15])
    business_travel = np.random.choice(
        ["Non-Travel", "Travel_Rarely", "Travel_Frequently"], n, p=[0.2, 0.55, 0.25]
    )

    # ---- Latent "attrition risk" used to generate a realistic target ----
    overtime_num = (overtime == "Yes").astype(int)
    travel_num = pd.Series(business_travel).map(
        {"Non-Travel": 0, "Travel_Rarely": 0.5, "Travel_Frequently": 1}
    ).values

    risk_score = (
        0.55 * overtime_num
        - 0.00008 * monthly_income
        - 0.06 * years_at_company
        - 0.20 * job_satisfaction
        - 0.18 * work_life_balance
        - 0.12 * environment_satisfaction
        + 0.05 * distance_from_home / 10
        + 0.10 * num_companies_worked / 3
        + 0.30 * travel_num
        + 0.10 * years_since_promotion / 5
        - 0.10 * job_level
        + np.random.normal(0, 0.7, n)  # noise
    )

    prob_attrition = 1 / (1 + np.exp(-risk_score))
    attrition = (prob_attrition > np.median(prob_attrition)).astype(int)
    # small random flip so it's not a perfect median split
    flip_mask = np.random.rand(n) < 0.05
    attrition[flip_mask] = 1 - attrition[flip_mask]

    df = pd.DataFrame(
        {
            "age": age,
            "monthly_income": monthly_income.round(2),
            "years_at_company": years_at_company,
            "years_since_last_promotion": years_since_promotion,
            "years_with_current_manager": years_with_manager,
            "distance_from_home": distance_from_home,
            "job_level": job_level,
            "num_companies_worked": num_companies_worked,
            "training_times_last_year": training_times_last_year,
            "overtime": overtime,
            "job_satisfaction": job_satisfaction,
            "work_life_balance": work_life_balance,
            "environment_satisfaction": environment_satisfaction,
            "performance_rating": performance_rating,
            "percent_salary_hike": percent_salary_hike,
            "department": department,
            "job_role": job_role,
            "marital_status": marital_status,
            "business_travel": business_travel,
            "attrition": attrition,  # target: 1 = left the company, 0 = stayed
        }
    )
    return df


if __name__ == "__main__":
    df = generate_dataset()
    out_path = "data/employee_data.csv"
    df.to_csv(out_path, index=False)
    print(f"Generated {len(df)} rows -> {out_path}")
    print(df["attrition"].value_counts(normalize=True).rename("proportion"))
