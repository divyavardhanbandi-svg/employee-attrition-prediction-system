"""
predict.py
----------
Loads the trained attrition model and scores individual employee(s)
for their probability of leaving the company.

Usage:
    python src/predict.py
"""

import joblib
import pandas as pd

MODEL_PATH = "models/attrition_model.pkl"


def load_model(path=MODEL_PATH):
    return joblib.load(path)


def score_employee(model, employee: dict):
    """
    employee: dict with keys matching the training features:
        age, monthly_income, years_at_company, years_since_last_promotion,
        years_with_current_manager, distance_from_home, job_level,
        num_companies_worked, training_times_last_year, job_satisfaction,
        work_life_balance, environment_satisfaction, performance_rating,
        percent_salary_hike, overtime, department, job_role,
        marital_status, business_travel
    """
    df = pd.DataFrame([employee])
    proba = model.predict_proba(df)[0, 1]  # probability of attrition
    pred = model.predict(df)[0]

    if proba >= 0.7:
        risk_band = "High Risk"
    elif proba >= 0.4:
        risk_band = "Medium Risk"
    else:
        risk_band = "Low Risk"

    return {
        "predicted_class": "Likely to Leave" if pred == 1 else "Likely to Stay",
        "attrition_probability": round(float(proba), 4),
        "risk_band": risk_band,
    }


if __name__ == "__main__":
    model = load_model()

    sample_employees = [
        {
            "age": 26,
            "monthly_income": 3200,
            "years_at_company": 1,
            "years_since_last_promotion": 1,
            "years_with_current_manager": 1,
            "distance_from_home": 28,
            "job_level": 1,
            "num_companies_worked": 3,
            "training_times_last_year": 1,
            "job_satisfaction": 1,
            "work_life_balance": 1,
            "environment_satisfaction": 2,
            "performance_rating": 3,
            "percent_salary_hike": 11,
            "overtime": "Yes",
            "department": "Sales",
            "job_role": "Representative",
            "marital_status": "Single",
            "business_travel": "Travel_Frequently",
        },
        {
            "age": 42,
            "monthly_income": 11000,
            "years_at_company": 15,
            "years_since_last_promotion": 2,
            "years_with_current_manager": 6,
            "distance_from_home": 5,
            "job_level": 4,
            "num_companies_worked": 1,
            "training_times_last_year": 3,
            "job_satisfaction": 4,
            "work_life_balance": 3,
            "environment_satisfaction": 4,
            "performance_rating": 4,
            "percent_salary_hike": 18,
            "overtime": "No",
            "department": "Engineering",
            "job_role": "Manager",
            "marital_status": "Married",
            "business_travel": "Travel_Rarely",
        },
    ]

    for i, emp in enumerate(sample_employees, start=1):
        result = score_employee(model, emp)
        print(f"\nEmployee {i}: {emp}")
        print("Result:", result)
