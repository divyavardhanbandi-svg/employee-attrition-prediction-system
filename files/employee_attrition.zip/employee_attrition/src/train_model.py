"""
train_model.py
---------------
Loads the employee dataset, preprocesses it, trains two models
(Logistic Regression + Random Forest), evaluates them, and saves
the best-performing model + preprocessing pipeline to disk.

Usage:
    python src/train_model.py
"""

import os
import joblib
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import seaborn as sns

from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler, OneHotEncoder
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import (
    accuracy_score,
    precision_score,
    recall_score,
    f1_score,
    roc_auc_score,
    roc_curve,
    confusion_matrix,
    classification_report,
)

DATA_PATH = "data/employee_data.csv"
MODEL_DIR = "models"
TARGET = "attrition"

NUMERIC_FEATURES = [
    "age",
    "monthly_income",
    "years_at_company",
    "years_since_last_promotion",
    "years_with_current_manager",
    "distance_from_home",
    "job_level",
    "num_companies_worked",
    "training_times_last_year",
    "job_satisfaction",
    "work_life_balance",
    "environment_satisfaction",
    "performance_rating",
    "percent_salary_hike",
]
CATEGORICAL_FEATURES = [
    "overtime",
    "department",
    "job_role",
    "marital_status",
    "business_travel",
]


def load_data(path=DATA_PATH):
    if not os.path.exists(path):
        raise FileNotFoundError(
            f"{path} not found. Run `python data/generate_data.py` first, "
            f"or replace it with your own HR dataset."
        )
    return pd.read_csv(path)


def build_preprocessor():
    numeric_transformer = StandardScaler()
    categorical_transformer = OneHotEncoder(handle_unknown="ignore")

    preprocessor = ColumnTransformer(
        transformers=[
            ("num", numeric_transformer, NUMERIC_FEATURES),
            ("cat", categorical_transformer, CATEGORICAL_FEATURES),
        ]
    )
    return preprocessor


def evaluate_model(name, model, X_test, y_test):
    y_pred = model.predict(X_test)
    y_proba = model.predict_proba(X_test)[:, 1]

    metrics = {
        "model": name,
        "accuracy": accuracy_score(y_test, y_pred),
        "precision": precision_score(y_test, y_pred),
        "recall": recall_score(y_test, y_pred),
        "f1_score": f1_score(y_test, y_pred),
        "roc_auc": roc_auc_score(y_test, y_proba),
    }

    print(f"\n=== {name} ===")
    for k, v in metrics.items():
        if k != "model":
            print(f"{k:>10}: {v:.4f}")
    print("\nClassification report:")
    print(classification_report(y_test, y_pred, target_names=["Stayed", "Left"]))

    return metrics, y_pred, y_proba


def plot_confusion_matrix(y_test, y_pred, name, out_path):
    cm = confusion_matrix(y_test, y_pred)
    plt.figure(figsize=(5, 4))
    sns.heatmap(
        cm,
        annot=True,
        fmt="d",
        cmap="Blues",
        xticklabels=["Stayed", "Left"],
        yticklabels=["Stayed", "Left"],
    )
    plt.title(f"Confusion Matrix - {name}")
    plt.ylabel("Actual")
    plt.xlabel("Predicted")
    plt.tight_layout()
    plt.savefig(out_path)
    plt.close()


def plot_roc_curves(results, out_path):
    plt.figure(figsize=(6, 5))
    for name, (y_test, y_proba) in results.items():
        fpr, tpr, _ = roc_curve(y_test, y_proba)
        auc = roc_auc_score(y_test, y_proba)
        plt.plot(fpr, tpr, label=f"{name} (AUC = {auc:.3f})")
    plt.plot([0, 1], [0, 1], "k--", label="Random")
    plt.xlabel("False Positive Rate")
    plt.ylabel("True Positive Rate")
    plt.title("ROC Curve Comparison")
    plt.legend()
    plt.tight_layout()
    plt.savefig(out_path)
    plt.close()


def main():
    os.makedirs(MODEL_DIR, exist_ok=True)
    os.makedirs("reports", exist_ok=True)

    df = load_data()
    X = df[NUMERIC_FEATURES + CATEGORICAL_FEATURES]
    y = df[TARGET]

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=42, stratify=y
    )

    preprocessor = build_preprocessor()

    models = {
        "Logistic Regression": LogisticRegression(max_iter=1000, class_weight="balanced"),
        "Random Forest": RandomForestClassifier(
            n_estimators=300, max_depth=8, random_state=42, class_weight="balanced"
        ),
    }

    all_metrics = []
    roc_data = {}
    fitted_pipelines = {}

    for name, model in models.items():
        pipe = Pipeline(steps=[("preprocessor", preprocessor), ("classifier", model)])
        pipe.fit(X_train, y_train)
        metrics, y_pred, y_proba = evaluate_model(name, pipe, X_test, y_test)
        all_metrics.append(metrics)
        roc_data[name] = (y_test, y_proba)
        fitted_pipelines[name] = pipe

        cm_path = f"reports/confusion_matrix_{name.replace(' ', '_').lower()}.png"
        plot_confusion_matrix(y_test, y_pred, name, cm_path)

    plot_roc_curves(roc_data, "reports/roc_curve_comparison.png")

    metrics_df = pd.DataFrame(all_metrics).sort_values("roc_auc", ascending=False)
    print("\n=== Model Comparison (sorted by ROC-AUC) ===")
    print(metrics_df.to_string(index=False))
    metrics_df.to_csv("reports/model_comparison.csv", index=False)

    best_model_name = metrics_df.iloc[0]["model"]
    best_pipeline = fitted_pipelines[best_model_name]

    model_path = os.path.join(MODEL_DIR, "attrition_model.pkl")
    joblib.dump(best_pipeline, model_path)
    print(f"\nBest model: {best_model_name}")
    print(f"Saved best pipeline -> {model_path}")

    if "Random Forest" in fitted_pipelines:
        rf_pipe = fitted_pipelines["Random Forest"]
        ohe_features = (
            rf_pipe.named_steps["preprocessor"]
            .named_transformers_["cat"]
            .get_feature_names_out(CATEGORICAL_FEATURES)
        )
        feature_names = NUMERIC_FEATURES + list(ohe_features)
        importances = rf_pipe.named_steps["classifier"].feature_importances_
        fi_df = pd.DataFrame(
            {"feature": feature_names, "importance": importances}
        ).sort_values("importance", ascending=False)
        fi_df.to_csv("reports/feature_importance_rf.csv", index=False)

        plt.figure(figsize=(8, 6))
        sns.barplot(data=fi_df.head(12), x="importance", y="feature", color="seagreen")
        plt.title("Top Feature Importances (Random Forest)")
        plt.tight_layout()
        plt.savefig("reports/feature_importance_rf.png")
        plt.close()

    print("\nAll reports saved in reports/")


if __name__ == "__main__":
    main()
